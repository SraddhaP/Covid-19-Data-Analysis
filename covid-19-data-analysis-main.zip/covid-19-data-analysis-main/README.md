# Covid-19 Data Analysis
This project involves performing exploratory data analysis using Python and creating a COVID-19 dashboard in Tableau. The focus is on understanding the impact of Covid-19 in India, including vaccination status, and generating visualizations of global Covid-19 cases, deaths, and recoveries using Tableau.
